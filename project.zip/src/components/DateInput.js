import React from 'react';

const DateInput = ({ label, value, onChange }) => {
  return (
    <div className="mb-4">
      <label htmlFor={label} className="block text-gray-700 text-sm font-bold mb-2">
        {label}
      </label>
      <input
        type="date"
        id={label}
        value={value}
        onChange={onChange}
        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
      />
    </div>
  );
};

export default DateInput;