import React from 'react';

const CalculatorButton = ({ onClick, text }) => {
  return (
    <button
      onClick={onClick}
      className="w-full mt-3 bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-black focus:ring-opacity-50"
    >
      {text}
    </button>
  );
};

export default CalculatorButton;