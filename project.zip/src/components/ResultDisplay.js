import React from 'react';
import { formatDate } from '../utils/dateCalculations';

const ResultDisplay = ({ countedDays, caducityDate, exceptedDays, materia }) => {
  if (!countedDays || !caducityDate) {
    return null;
  }

  const groupedDays = countedDays.reduce((acc, date) => {
    const monthYear = date.toLocaleDateString('es-MX', { month: 'long', year: 'numeric' });
    if (!acc[monthYear]) {
      acc[monthYear] = [];
    }
    acc[monthYear].push(date.getDate());
    return acc;
  }, {});

  // Asegurarse de que exceptedDays sea un array antes de usar reduce
  const safeExceptedDays = Array.isArray(exceptedDays) ? exceptedDays : [];

  const groupedExceptedDays = safeExceptedDays.reduce((acc, date) => {
    const monthYear = date.toLocaleDateString('es-MX', { month: 'long', year: 'numeric' });
    if (!acc[monthYear]) {
      acc[monthYear] = [];
    }
    acc[monthYear].push(date.getDate());
    return acc;
  }, {});

  const getExceptedReason = (date, materia) => {
    const dayOfWeek = date.getDay();
    const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6); // Domingo = 0, Sábado = 6

    if (materia === 'mercantil') {
      if (isWeekend) return 'Fin de semana';
      return 'Día inhábil del calendario judicial';
    }
    // Para materia civil, solo se exceptúan los días inhábiles del calendario judicial
    return 'Día inhábil del calendario judicial';
  };

  return (
    <div className="mt-6 p-4 bg-gray-50 rounded-lg shadow-inner">
      <h3 className="text-lg font-semibold text-gray-800 mb-3">Días Contados:</h3>
      {Object.entries(groupedDays).map(([monthYear, days]) => (
        <p key={monthYear} className="text-gray-700 mb-1">
          <span className="font-medium">{monthYear}:</span> {days.join(', ')}
        </p>
      ))}

      {safeExceptedDays.length > 0 && (
        <div className="mt-4">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Días Exceptuados del Conteo:</h3>
          {Object.entries(groupedExceptedDays).map(([monthYear, days]) => (
            <div key={monthYear} className="mb-2">
              <p className="font-medium text-gray-700">{monthYear}:</p>
              <ul className="list-disc list-inside text-gray-600 ml-4">
                {days.map((day, index) => {
                  // Para obtener el año correcto, se puede usar el año de la fecha de caducidad o del primer día contado
                  const year = caducityDate.getFullYear(); 
                  const monthIndex = new Date(monthYear).getMonth();
                  const fullDate = new Date(year, monthIndex, day);
                  return (
                    <li key={index}>
                      {day} - {getExceptedReason(fullDate, materia)}
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>
      )}

      <h3 className="text-xl font-bold text-red-600 mt-4">
        Día de Caducidad: {formatDate(caducityDate)}
      </h3>
    </div>
  );
};

export default ResultDisplay;

// DONE