import React from 'react';

// Días inhábiles del Poder Judicial de Jalisco
// Esta lista debe ser actualizada anualmente o según se publique el calendario oficial.
const INHABIL_DAYS = [
  // 2024
  '2024-09-16', '2024-09-28', '2024-09-30',
  '2024-10-01', '2024-10-11', '2024-10-12',
  '2024-11-01', '2024-11-02', '2024-11-18',
  '2024-12-16', '2024-12-17', '2024-12-18', '2024-12-19', '2024-12-20',
  '2024-12-21', '2024-12-22', '2024-12-23', '2024-12-24', '2024-12-25',
  '2024-12-26', '2024-12-27', '2024-12-28', '2024-12-29', '2024-12-30', '2024-12-31',
  // 2025
  '2025-01-01', '2025-01-02', '2025-01-03',
  '2025-02-03',
  '2025-03-17',
  '2025-04-28', '2025-04-29', '2025-04-30',
  '2025-05-01', '2025-05-02', '2025-05-03', '2025-05-04', '2025-05-05',
  '2025-05-06', '2025-05-07', '2025-05-08', '2025-05-09', '2025-05-10',
  '2025-06-09',
  '2025-07-16', '2025-07-17', '2025-07-18', '2025-07-19', '2025-07-20',
  '2025-07-21', '2025-07-22', '2025-07-23', '2025-07-24', '2025-07-25',
  '2025-07-26', '2025-07-27', '2025-07-28', '2025-07-29', '2025-07-30', '2025-07-31',
  '2025-08-01',
  '2025-09-15', '2025-09-16', '2025-09-28', '2025-09-29',
  '2025-10-02', '2025-10-17',
  '2025-12-15', '2025-12-16', '2025-12-17', '2025-12-18', '2025-12-19',
  '2025-12-20', '2025-12-21', '2025-12-22', '2025-12-23', '2025-12-24',
  '2025-12-25', '2025-12-26', '2025-12-27', '2025-12-28', '2025-12-29', '2025-12-30', '2025-12-31'
];

// Función para formatear una fecha a 'YYYY-MM-DD'
const formatToYYYYMMDD = (date) => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Función para verificar si una fecha es inhábil según el calendario de Jalisco
export const isJaliscoInhabil = (date) => {
  const formattedDate = formatToYYYYMMDD(date);
  return INHABIL_DAYS.includes(formattedDate);
};

// Función para calcular la caducidad civil (días naturales)
export const calculateCivilCaducity = (startDate) => {
  const countedDays = [];
  const exceptedDays = [];
  let currentDate = new Date(startDate);
  currentDate.setDate(currentDate.getDate() + 1); // Empezar a contar desde el día siguiente

  for (let i = 0; i < 180; i++) {
    if (isJaliscoInhabil(currentDate)) {
      exceptedDays.push(new Date(currentDate));
    }
    countedDays.push(new Date(currentDate));
    currentDate.setDate(currentDate.getDate() + 1);
  }

  const caducityDate = new Date(startDate);
  caducityDate.setDate(caducityDate.getDate() + 180);

  return { countedDays, caducityDate, exceptedDays };
};

// Función para calcular la caducidad mercantil (días hábiles)
export const calculateMercantilCaducity = (startDate) => {
  const countedDays = [];
  const exceptedDays = [];
  let currentDate = new Date(startDate);
  currentDate.setDate(currentDate.getDate() + 1); // Empezar a contar desde el día siguiente

  let daysToCount = 120;
  while (daysToCount > 0) {
    const dayOfWeek = currentDate.getDay(); // 0 = Domingo, 6 = Sábado
    const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6);

    if (isWeekend || isJaliscoInhabil(currentDate)) {
      exceptedDays.push(new Date(currentDate));
    } else {
      countedDays.push(new Date(currentDate));
      daysToCount--;
    }
    currentDate.setDate(currentDate.getDate() + 1);
  }

  const caducityDate = new Date(currentDate);
  caducityDate.setDate(caducityDate.getDate() - 1); // El día anterior al que se detuvo el contador

  return { countedDays, caducityDate, exceptedDays };
};

// Función para formatear la fecha
export const formatDate = (date) => {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return date.toLocaleDateString('es-MX', options);
};