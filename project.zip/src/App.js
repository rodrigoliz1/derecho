import React, { useState } from 'react';
import DateInput from './components/DateInput';
import CalculatorButton from './components/CalculatorButton';
import ResultDisplay from './components/ResultDisplay';
import { calculateCivilCaducity, calculateMercantilCaducity } from './utils/dateCalculations';

const App = () => {
  const [materia, setMateria] = useState(null); // 'civil' o 'mercantil'
  const [lastAutoDate, setLastAutoDate] = useState('');
  const [calculationResult, setCalculationResult] = useState(null);

  const handleCalculate = () => {
    if (!lastAutoDate) {
      alert('Por favor, ingresa la fecha del último auto.');
      return;
    }

    const startDate = new Date(lastAutoDate + 'T00:00:00'); // Asegura que la fecha sea GMT-0 para evitar problemas de zona horaria

    let result = null;
    if (materia === 'civil') {
      result = calculateCivilCaducity(startDate);
    } else if (materia === 'mercantil') {
      result = calculateMercantilCaducity(startDate);
    }
    setCalculationResult(result);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
        <h1 className="text-3xl font-bold text-center text-gray-900 mb-6">
          Calculadora de Caducidad
        </h1>

        {!materia ? (
          <div className="space-y-4">
            <p className="text-center text-gray-700 text-lg mb-4">¿Qué materia?</p>
            <CalculatorButton onClick={() => setMateria('civil')} text="MATERIA CIVIL" />
            <CalculatorButton onClick={() => setMateria('mercantil')} text="MATERIA MERCANTIL" />
          </div>
        ) : (
          <div>
            <h2 className="text-2xl font-semibold text-center text-gray-800 mb-5">
              Materia {materia.charAt(0).toUpperCase() + materia.slice(1)}
            </h2>
            <DateInput
              label="Fecha del último auto que dio impulso procesal:"
              value={lastAutoDate}
              onChange={(e) => setLastAutoDate(e.target.value)}
            />
            <CalculatorButton onClick={handleCalculate} text="Calcular" />

            {calculationResult && (
              <ResultDisplay
                countedDays={calculationResult.countedDays}
                caducityDate={calculationResult.caducityDate}
                exceptedDays={calculationResult.exceptedDays || []} // Asegura que siempre sea un array
                materia={materia}
              />
            )}

            <CalculatorButton onClick={() => {
              setMateria(null);
              setLastAutoDate('');
              setCalculationResult(null);
            }} text="Regresar" />
          </div>
        )}
      </div>
    </div>
  );
};

export default App;

// DONE